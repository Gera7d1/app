#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_PERSONA 3

struct person {
    char emri[20];
    char mbiemri[20];
    int mosha;
} person[MAX_PERSONA];

int personi_vjeter(struct person p[]) {
    int max = 0;
    for (int i = 0; i < MAX_PERSONA; i++) {
        if (p[i].mosha > max) {
            max = p[i].mosha;
        }
    }
    return max;
}

void emriPerpara(struct person p[]) {
    for (int i = 0; i < MAX_PERSONA - 1; i++) {
        if (strcmp(p[i].emri, p[i + 1].emri) > 0) {
            printf("\nEmri: %c", tolower(p[i].emri[0]));
        } else if (strcmp(p[i].emri, p[i + 1].emri) == 0) {
            printf("\nEmri: %c", tolower(p[i].emri[0]));
        } else {
            printf("\nEmri: %c", tolower(p[i].emri[0]));
        }
    }
}

void rendit(struct person p[]) {
    for (int i = 0; i < MAX_PERSONA - 1; i++) {
        for (int j = i + 1; j < MAX_PERSONA; j++) {
            if (strcmp(p[i].emri, p[j].emri) > 0) {
                struct person temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            } else if (strcmp(p[i].emri, p[j].emri) == 0) {
                if (strcmp(p[i].mbiemri, p[j].mbiemri) > 0) {
                    struct person temp = p[i];
                    p[i] = p[j];
                    p[j] = temp;
                }
            }
        }
    }
}

struct person printoDhena(struct person person) {
    printf("\nEmri: %c", tolower(person.emri[0]));
    printf("\nMbiemri: %s", person.mbiemri);
    printf("\nMosha: %d", person.mosha);
    return person;
}

int numriPersonaveMeShkronje(struct person p[], char shkronja) {
    int count = 0;
    for (int i = 0; i < MAX_PERSONA; i++) {
        if (tolower(p[i].emri[0]) == tolower(shkronja)) {
            count++;
        }
    }
    return count;
}

struct person personMeMbiemrinMeTeGjate(struct person p[]) {
    struct person personMeMbiemrinGjatesiMax = p[0];
    for (int i = 1; i < MAX_PERSONA; i++) {
        if (strlen(p[i].mbiemri) > strlen(personMeMbiemrinGjatesiMax.mbiemri)) {
            personMeMbiemrinGjatesiMax = p[i];
        }
    }
    return personMeMbiemrinGjatesiMax;
}

int main() {
    for (int i = 0; i < MAX_PERSONA; i++) {
        printf("Jep emrin e personit: ");
        scanf("%s", person[i].emri);
        printf("Jep mbiemrin e personit: ");
        scanf("%s", person[i].mbiemri);
        printf("Jep moshen e personit: ");
        scanf("%d", &person[i].mosha);
    }

    printf("\nMosha me e madhe: %d", personi_vjeter(person));
    emriPerpara(person);
    
    char shkronja;
    printf("\nJepni shkronjen per te numeruar personat qe fillon emri me ate shkronje: ");
    scanf(" %c", &shkronja);
    printf("Numri i personave qe fillon emri me shkronjen '%c': %d", shkronja, numriPersonaveMeShkronje(person, shkronja));

    struct person personMeMbiemrinGjatesi = personMeMbiemrinMeTeGjate(person);
    printf("\nPersoni me mbiemrin me te gjate eshte: %s %s", personMeMbiemrinGjatesi.emri, personMeMbiemrinGjatesi.mbiemri);

    for (int i = 0; i < MAX_PERSONA; i++) {
        printoDhena(person[i]);
    }

    return 0;
}
