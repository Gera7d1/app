#include <stdio.h>

#define MAX_SIZE 100

int is_symmetric(int arr[], int start, int end) {
    if (start >= end) {
        return 1;
    }
    if (arr[start] != arr[end]) {
        return 0;
    }
    return is_symmetric(arr, start + 1, end - 1);
}

int main() {
    int n;
    printf("Shkruani gjatesine e vektorit: ");
    scanf("%d", &n);
    int arr[MAX_SIZE];
    printf("Shkruani elementet e vektorit:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    if (is_symmetric(arr, 0, n - 1)) {
        printf("Vektori eshte simetrik.\n");
    } else {
        printf("Vektori nuk eshte simetrik.\n");
    }
    return 0;
}