#include <stdio.h>

int product_even(int n) {
    if (n <= 0) {
        return 1;
    } else {
        if (n % 2 == 0) {
            return n * product_even(n - 1);
        } else {
            return product_even(n - 1);
        }
    }
}

int main() {
    int n;
    printf("Shkruani numrin e kufizave te pare: ");
    scanf("%d", &n);
    printf("Prodhimi i numrave cift per %d kufizat e pare: %d\n", n, product_even(n));
    return 0;
}