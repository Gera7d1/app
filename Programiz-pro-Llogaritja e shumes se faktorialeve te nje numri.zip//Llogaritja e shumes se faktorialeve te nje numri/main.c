#include <stdio.h>

int factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

int sum_factorials(int n) {
    if (n == 0) {
        return 0;
    } else {
        return factorial(n) + sum_factorials(n - 1);
    }
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Sum of factorials up to %d: %d\n", n, sum_factorials(n));
    return 0;
}