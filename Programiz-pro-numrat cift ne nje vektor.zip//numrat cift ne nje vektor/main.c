#include <stdio.h>

#define MAX_SIZE 100

int count_even(int arr[], int size) {
    if (size == 0) {
        return 0;
    } else {
        if (arr[size - 1] % 2 == 0) {
            return 1 + count_even(arr, size - 1);
        } else {
            return count_even(arr, size - 1);
        }
    }
}

int main() {
    int n;
    printf("Shkruani gjatesine e vektorit: ");
    scanf("%d", &n);
    int arr[MAX_SIZE];
    printf("Shkruani elementet e vektorit:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    printf("Numri i numrave cift ne vektor: %d\n", count_even(arr, n));
    return 0;
}