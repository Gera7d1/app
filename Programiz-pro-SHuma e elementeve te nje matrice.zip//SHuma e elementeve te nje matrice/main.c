#include <stdio.h>

#define ROWS 3
#define COLS 3

int sum_matrix(int mat[ROWS][COLS], int row, int col) {
    if (row < 0 || col < 0) {
        return 0;
    }
    else {
        return mat[row][col] + sum_matrix(mat, row - 1, col) + sum_matrix(mat, row, col - 1) - sum_matrix(mat, row - 1, col - 1);
    }
}

int main() {
    int mat[ROWS][COLS];
    printf("Enter the elements of the matrix (%d x %d):\n", ROWS, COLS);
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            scanf("%d", &mat[i][j]);
        }
    }
    printf("Sum of elements in the matrix: %d\n", sum_matrix(mat, ROWS - 1, COLS - 1));
    return 0;
}