#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_AUTOR 10
#define MAX_LIBRA 20

struct libri{
    int id;
    int faqe;
    char isbn[13]; // Ndryshimi për të përfshirë karakterin NULL terminator
    char titulli[50]; // Ndryshimi për të përmirësuar gjatësinë e titullit
} librat[MAX_LIBRA];

struct autori {
    int id;
    char emri[20];
    char mbiemri[20];
    int nr_librave;
    struct libri librat[5]; // Ndryshimi për të ndryshuar madhësinë e strukturës së librit
} autoret[MAX_AUTOR];

int nr_librave = 0;
int nr_autoreve = 0;

// Deklarimet e funksioneve
int nr_librave_isbn_shkronje(struct libri librat[]);
void shto_autor_dhe_libra(void);
void listo_librat_autor(char emri_autorit[]);
void menu(void);

int main() {
    char emri_autorit[20];
    int opsioni;

    do {
        menu();
        printf("Zgjidhni opsionin tuaj: ");
        scanf("%d", &opsioni);

        switch (opsioni) {
            case 1:
                shto_autor_dhe_libra();
                break;
            case 2:
                printf("Jepni emrin e autorit: ");
                scanf("%s", emri_autorit);
                listo_librat_autor(emri_autorit);
                break;
            case 3:
                // Shtoni opsionet e tjera të menysë nëse ka
                break;
            case 0:
                printf("Dilni nga programi.\n");
                break;
            default:
                printf("Opsioni i zgjedhur nuk është i vlefshëm.\n");
        }
    } while (opsioni != 0);

    return 0;
}

// Funksioni për të shtuar autorin dhe librat e tij
void shto_autor_dhe_libra(void) {
    // Implementimi i logjikës për të shtuar autoret dhe librat e tyre
}

// Funksioni për të listuar të gjithë librat e një autori
void listo_librat_autor(char emri_autorit[]) {
    int i, j;
    for (i = 0; i < nr_autoreve; i++) {
        if (strcmp(autoret[i].emri, emri_autorit) == 0) {
            printf("Librat e autorit %s:\n", emri_autorit);
            for (j = 0; j < autoret[i].nr_librave; j++) {
                printf("Titulli: %s\n", autoret[i].librat[j].titulli);
                printf("ISBN: %s\n", autoret[i].librat[j].isbn);
                printf("Numri i faqeve: %d\n", autoret[i].librat[j].faqe);
                printf("\n");
            }
            return;
        }
    }
    printf("Autori %s nuk u gjet.\n", emri_autorit);
}

// Funksioni për të shfaqur menu-n
void menu(void) {
    printf("\nMENU\n");
    printf("1. Shto autor dhe libra\n");
    printf("2. Listo librat e nje autori\n");
    printf("3. Opsion i ri\n");
    printf("0. Dil\n");
}
