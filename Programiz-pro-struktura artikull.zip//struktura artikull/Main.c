#include <stdio.h>
#include <stdlib.h> // Për përdorimin e funksionit exit()

#define GJAT_EMER 25
#define MAX_ARTIKULL 100

struct artikull {
    int numri;
    char emri[GJAT_EMER + 1];
    int gjendja;
} inventari[MAX_ARTIKULL];

int nr_artikull = 0;

int gjej_artikull(int numer);
void shto(void);
void kerko(void);
void update(void);
void printo(void);
int lexo_rresht(char str[], int n);
void printo_menu(void);
int numriGjendjesZero(void);
void artikujtMeKodNjeShifror(void);

int main() {
    char kodi;

    for (;;) {
        printo_menu();

        printf("Fut kodin e veprimit: ");
        scanf(" %c", &kodi);
        while (getchar() != '\n') /* kalon deri te fundi i rreshtit */
            ;

        switch (kodi) {
            case 's':
                shto();
                break;
            case 'k':
                kerko();
                break;
            case 'u':
                update();
                break;
            case 'p':
                printo();
                break;
            case 'q':
                exit(0);
            default:
                printf("Kod i gabuar\n");
        }
        printf("\n");
    }
}

int gjej_artikull(int numri) {
    for (int i = 0; i < nr_artikull; i++)
        if (inventari[i].numri == numri)
            return i;
    return -1;
}

void shto(void) {
    int artikull_nr;
    if (nr_artikull == MAX_ARTIKULL) {
        printf("Databaza eshte plot; nuk mund te shtohet artikull.\n");
        return;
    }
    printf("Fut numrin e artikullit: ");
    scanf("%d", &artikull_nr);
    if (gjej_artikull(artikull_nr) >= 0) {
        printf("Artikulli egziston.\n");
        return;
    }

    inventari[nr_artikull].numri = artikull_nr;
    printf("Jep emrin e artikullit: ");
    lexo_rresht(inventari[nr_artikull].emri, GJAT_EMER);
    printf("Jep gjendjen e artikullit: ");
    scanf("%d", &inventari[nr_artikull].gjendja);
    nr_artikull++;
}

void kerko(void) {
    int i, numer;
    printf("Jep numrin e artikullit: ");
    scanf("%d", &numer);
    i = gjej_artikull(numer);
    if (i >= 0) {
        printf("Emri i artikullit: %s\n", inventari[i].emri);
        printf("Gjendja e artikullit: %d\n", inventari[i].gjendja);
    } else
        printf("Artikulli nuk u gjet.\n");
}

void update(void) {
    int i, numer, ndryshimi;
    printf("Jep numrin e artikullit: ");
    scanf("%d", &numer);
    i = gjej_artikull(numer);
    if (i >= 0) {
        printf("Jep ndryshimin ne gjendje te artikullit: ");
        scanf("%d", &ndryshimi);
        inventari[i].gjendja += ndryshimi;
    } else
        printf("Artikulli nuk u gjet.\n");
}

void printo(void) {
    printf("Numri i Artikullit Emri i Artikullit Gjendja e Artikullit\n");
    for (int i = 0; i < nr_artikull; i++)
        printf("%7d %25s %25d\n", inventari[i].numri, inventari[i].emri, inventari[i].gjendja);
}

int lexo_rresht(char str[], int n) {
    int ch, i = 0;
    while ((ch = getchar()) == ' ')
        ;
    while ((ch = getchar()) != '\n') {
        if (i < n)
            str[i++] = ch;
    }
    str[i] = '\0';
    return i;
}

void printo_menu(void) {
    printf("\nZgjidhni nje veprim:\n");
    printf("1. Shto artikull\n");
    printf("2. Kerko artikull\n");
    printf("3. Update artikull\n");
    printf("4. Printo inventarin\n");
    printf("5. Numri i artikujve me gjendjen 0\n");
    printf("6. Artikujt me kod njëshifror\n");
    printf("7. Quit\n");
}

int numriGjendjesZero(void) {
    int count = 0;
    for (int i = 0; i < nr_artikull; i++) {
        if (inventari[i].gjendja == 0) {
            count++;
        }
    }
    return count;
}

void artikujtMeKodNjeShifror(void) {
    printf("Artikujt me kod njëshifror:\n");
    for (int i = 0; i < nr_artikull; i++) {
        if (inventari[i].numri >= 0 && inventari[i].numri <= 9) {
            printf("%7d %25s %25d\n", inventari[i].numri, inventari[i].emri, inventari[i].gjendja);
        }
    }
}
