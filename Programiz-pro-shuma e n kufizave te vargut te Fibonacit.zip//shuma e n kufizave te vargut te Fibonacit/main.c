#include <stdio.h>

int fibonacci(int n) {
    if (n <= 1) {
        return n;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

int sum_fibonacci(int n) {
    if (n <= 0) {
        return 0;
    } else {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += fibonacci(i);
        }
        return sum;
    }
}

int main() {
    int n;
    printf("Shkruani numrin e kufizave te vargut te Fibonacci: ");
    scanf("%d", &n);
    
    printf("Shuma e %d-kufizave te vargut te Fibonacci: ", n);
    for (int i = 0; i < n; i++) {
        printf("%d", fibonacci(i));
        if (i != n - 1) {
            printf(" + ");
        }
    }
    printf(" = %d\n", sum_fibonacci(n));
    
    return 0;
}