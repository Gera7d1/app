#include <stdio.h>

//Fnksioni per llogaritjen e pikeve
int llogaritPiket (int topi1,int topi2){
 
  int piket =0;
  int x1=0,x2=0,x3=0;

  //Hellja e topit1
  if (topi1=='1')
  x1=1;
  else if(topi1=='2')
  x2=1;
  if(topi1=='3')
  x3=1;

  //Hellja e topit2
  if(topi2==1)
  x1=!x1;//Shkembimi i qelizave per topin 2
  else if(topi2==2)
  x2=!x2;//Shkembimi i qelizave per topin 2
  else if(topi2==3)
  x3=!x3;//shkembimi i qelizave per topin 2

  //Kontrolli per piket
  if(x1==0 &&x2==0 &&x3==0)
  piket=0;//Nuk ka pike
  else 
  piket=1;//Ka pike

  return piket;

}

int main(){
  //Hellja e topit 1 dhe 2
  int topi1,topi2;
  printf("Shkruaj helljen e topit 1:");
  scanf("%d",&topi1);
  printf("Shkruaj hedhjen e topit 2:");
  scanf("%d",&topi2);

  //Llogaritja e pikeve
  int piket=llogaritPiket(topi1,topi2);
  printf("Piket e arritura jane:%d\n",piket);

  return 0;
}